
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/contagem.dart';
import 'package:url_launcher/url_launcher.dart';
import 'custom_red_button.dart';

class ContagemCard extends StatelessWidget {
  final Contagem contagem;
  final VoidCallback onEditar;
  final VoidCallback onExcluir;
  final VoidCallback onAtualizar;

  const ContagemCard({
    Key? key,
    required this.contagem,
    required this.onEditar,
    required this.onExcluir,
    required this.onAtualizar,
  }) : super(key: key);

  Future<void> _launchURL(String urlString) async {
    final Uri url = Uri.parse(urlString.startsWith('http') ? urlString : 'https://$urlString');
    if (await canLaunchUrl(url)) {
      await launchUrl(url);
    }
  }

  Future<void> _validarContagem(BuildContext context) async {
    final url = Uri.parse('https://contagemapi.onrender.com/Contagem/validar');
    final response = await http.put(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(contagem.toJson()),
    );
    if (response.statusCode == 200 || response.statusCode == 204) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Contagem validada com sucesso')),
      );
      onAtualizar();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao validar contagem')),
      );
    }
  }

  Future<void> _entregarContagem(BuildContext context) async {
    final url = Uri.parse('https://contagemapi.onrender.com/Contagem/entregar');
    final response = await http.put(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(contagem.toJson()),
    );
    if (response.statusCode == 200 || response.statusCode == 204) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Contagem entregue com sucesso')),
      );
      onAtualizar();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro ao entregar contagem')),
      );
    }
  }

  @override

  void _confirmarExclusao(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('Confirmar exclusão'),
          content: Text('Deseja realmente excluir a contagem ${contagem.numContagem}?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: Text('Não'),
            ),
            CustomRedButton(
              text: 'Sim',
              onPressed: () async {
                final url = Uri.parse('https://contagemapi.onrender.com/Contagem/${contagem.idContagem}');
                final response = await http.delete(url);
                Navigator.of(dialogContext).pop();
                if (response.statusCode == 200 || response.statusCode == 204) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Contagem excluída com sucesso')),
                  );
                  onAtualizar();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Erro ao excluir contagem')),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  Widget build(BuildContext context) {
    return Card(
      color: Color(0xFFF5F5F5),
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(1.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              // mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: Icon(
                    contagem.entregue ? Icons.class_ : Icons.class_outlined,
                    color: contagem.entregue ? Colors.green : Colors.grey,
                  ),
                  onPressed: () => _entregarContagem(context),
                  tooltip: contagem.entregue ? 'Devolver' : 'Entregar',
                ),
                IconButton(
                  icon: Icon(
                    contagem.validado ? Icons.check_circle : Icons.check_circle_outline,
                    color: contagem.validado ? Colors.green : Colors.grey,
                  ),
                  onPressed: () => _validarContagem(context),
                  tooltip: contagem.validado ? 'Invalidar' : 'Validar',
                ),
              ],
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Card: ${contagem.numCard}',
                    style: TextStyle(
                      color: Color(0xFFA6193C),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text('Pontos de função: ${contagem.pontosDeFuncao}', style: TextStyle(fontWeight: FontWeight.bold)),
                  Text('Mês: ${contagem.mes}', style: TextStyle(fontWeight: FontWeight.bold))
                ],
              ),
            ),
            Column(
              children: [
                Text(
                  '${contagem.sistema}',
                  style: TextStyle(
                    color: Color(0xFFA6193C),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                RichText(
                  text: TextSpan(
                    style: DefaultTextStyle.of(context).style.copyWith(fontWeight: FontWeight.bold),
                    children: <TextSpan>[
                      // TextSpan(text: 'Contagem: '),
                      TextSpan(
                        text: contagem.numContagem.toString(),
                        style: TextStyle(color: Colors.blue),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => _launchURL(contagem.link),
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit, color: Color(0xFF646464)),
                      onPressed: onEditar,
                      tooltip: 'Editar',
                    ),
                    IconButton(
                      icon: Icon(Icons.delete, color: Color(0xFFA6193C)),
                      onPressed: () => _confirmarExclusao(context),
                      tooltip: 'Excluir',
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
